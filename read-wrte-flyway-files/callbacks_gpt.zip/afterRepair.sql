-- afterRepair.sql
DO $$
BEGIN
  RAISE NOTICE 'Repaired schema history successfully.';
END $$;
